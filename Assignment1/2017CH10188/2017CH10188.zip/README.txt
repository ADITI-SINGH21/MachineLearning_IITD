README
Report1_2017CH10188.pdf is the report file with all the questions answered.
Code is provided in Assignment1.ipnyb file (jupyter notebook) which has all the questions done in the order as given in assignment with all the required comments and markdowns 
